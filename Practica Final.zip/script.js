document.addEventListener('DOMContentLoaded', function() {
    console.log('Documento cargado.');
  
    // Validación del formulario de correo electrónico porque no se me ocurrio otra cosa que se viera formal profe jejeje
    document.getElementById('myForm').addEventListener('submit', function(event) {
      const email = document.getElementById('email').value;
      const error = document.getElementById('error');
  
      if (!email.includes('@')) {
        event.preventDefault(); 
        error.textContent = 'Por favor, ingresa un correo válido.';
      } else {
        error.textContent = ''; 
      }
    });
  
    document.getElementById('colorButton').addEventListener('click', function() {
      const colors = ['#FF5733', '#33FF57', '#3357FF', '#F3FF33', '#FF33F3'];
      const randomColor = colors[Math.floor(Math.random() * colors.length)];
      document.body.style.backgroundColor = randomColor;
    });
  });
  